﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ShopifyApp.User;
using ShopifyApp.Cashier;
using ShopifyApp.Purchace;

namespace ShopifyApp.User
{
    public partial class AdminForm : Form
    {
        public AdminForm()
        {
            InitializeComponent();
        }

        private void btnAddUsers_Click(object sender, EventArgs e)
        {
            this.Hide();
            RegistrationForm registrationForm = new RegistrationForm();
            registrationForm.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
           
        }

        private void lblChangePassword_Click(object sender, EventArgs e)
        {
            this.Hide();
            ChangePassword changePassword = new ChangePassword();
            
            changePassword.Show();
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Hide();
            LoginForm loginForm = new LoginForm();
            loginForm.ShowDialog();
        }

        private void btnShowPurchase_Click(object sender, EventArgs e)
        {
            ShowPurchaseReport objSB = new ShowPurchaseReport();
            //objSB.MdiParent = this.MdiParent;
            this.Hide();
            objSB.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            ShowSalesHistory objSB = new ShowSalesHistory();
            //objSB.MdiParent = this.MdiParent;
            this.Hide();
            objSB.Show();
        }
    }
}
