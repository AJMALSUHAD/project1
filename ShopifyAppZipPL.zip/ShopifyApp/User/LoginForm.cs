﻿using ShopifyBLL.ShopifyBL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
//using ShopifyBLL.ShopifyBL;
using ShopifyDTO.DTO;
using ShopifyApp.User;
using ShopifyApp.Stock_Managment;
using ShopifyApp.Cashier;
//using ShopifyApp.Stock_Managment;

namespace ShopifyApp
{
    public partial class LoginForm : Form
    {
        public LoginForm()
        {
            InitializeComponent();
        }



        //Login Method----------------------------

        private void button1_Click(object sender, EventArgs e)
        {
            UserDTO userDTO = new UserDTO();
            userDTO.UserId = txtUserId.Text;
            userDTO.Password = txtPassword.Text;
            userDTO.Type = cmbSelectUser.Text;

            bool validUser = UserBL.UserLogin(userDTO);
            try
            {
                if (validUser)
                {
                    if (userDTO.Type == "Admin")
                    {
                        this.Hide();
                        AdminForm adminForm = new AdminForm();
                        adminForm.Show();
                    }
                    else if (userDTO.Type == "Cashier")
                    {
                        this.Hide();
                        CashierMenu cashierMenu = new CashierMenu();
                        cashierMenu.Show();
                    }
                    else if (userDTO.Type == "Stock Manager")
                    {
                        this.Hide();
                        ///
                        Stock_Manager stock_Manager = new Stock_Manager();
                        stock_Manager.Show();
                    }

                }
                else
                {
                    lblMessaging.Text = "invalid credentials";
                }
            }
            catch (Exception exe)
            {
                lblMessaging.Text = "Invalid Username or Passsword";
                Console.Out.WriteLine("****error : StudentMarkBl.cs:GetNewStudentId:" + exe.Message.ToString());
            }
        }

            

     

        private void button1_Click_2(object sender, EventArgs e)
        {

        
            this.Hide();
            ChangePassword login = new ChangePassword();
            login.ShowDialog();

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }


        //UserID  validation------------------------

        private void txtUserId_Validating(object sender, CancelEventArgs e)
        {
            if (txtUserId.Text == string.Empty||txtUserId.TextLength<=2)
            {
                epUser.SetError(txtUserId, "User id Should contain atleast 6 characters!");
            }
            else
            {
                epUser.SetError(txtUserId, string.Empty);

            }
        }

        private void cmbSelectUser_SelectedIndexChanged(object sender, EventArgs e)
        {

        }



        //UserType  validation------------------------

        private void cmbSelectUser_Validating(object sender, CancelEventArgs e)
        {
            if (cmbSelectUser.Text == string.Empty)
            {
                epUser.SetError(cmbSelectUser, "Please Enter The User Type!");
            }
            else
            {
                epUser.SetError(cmbSelectUser, string.Empty);

            }
        }



        //Password  validation------------------------
        private void txtPassword_Validating(object sender, CancelEventArgs e)
        {
            if (txtPassword.Text == string.Empty||txtPassword.TextLength<=4)
            {
                epUser.SetError(txtPassword, "Password should Contain Atleast 8 characters!");
            }
            else
            {
                epUser.SetError(txtPassword, string.Empty);

            }

        }
    }
}
