﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ShopifyDTO.DTO;
using ShopifyApp.User;
using ShopifyBLL.ShopifyBL;

namespace ShopifyApp.User
{
    public partial class ChangePassword : Form
    {
        public ChangePassword()
        {
            InitializeComponent();
        }



        //passsword Changing Method---------------------------------

        private void btnsubmit_Click(object sender, EventArgs e)
        {
            int output = 0;
            UserDTO userDTO = new UserDTO();
            userDTO.UserId = txtUserId.Text;
            userDTO.NewPassword = txtNewPassord.Text;
            userDTO.ConfirmNewPassword = txtConfirmPassword.Text;

            try
            {

                if (txtNewPassord.Text == txtConfirmPassword.Text)
                {
                    output = UserBL.ChangePassword(userDTO);

                }
                
                else
                {
                    lblChangePassword.Text = "Reenter Password";
                }
            }
            catch (Exception ex)
            {
                Console.Out.WriteLine("****error : in change password presentation layer" + ex.Message.ToString());
            }
            if (output > 0)
            {
                lblChangePassword.Text = "Password change succesfully";
            }
            else
            {
                lblChangePassword.Text = "Re-enter Password";
            }

        }



        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Hide();
            LoginForm loginForm = new LoginForm();
            loginForm.Show();
        }
    }
}
