﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ShopifyBLL.ShopifyBL;
using ShopifyDTO.DTO;
using ShopifyApp.User;


namespace ShopifyApp
{
    public partial class RegistrationForm : Form
    {
        public RegistrationForm()
        {
            InitializeComponent();
        }


        //Method for Adding new User-----------------------------

        private void btnSave_Click(object sender, EventArgs e)
        {

            UserDTO userDTO = null;
            int output = 0;
            try
            {
                
                if (txtRName.Text == string.Empty && txtRUserid.Text == string.Empty && txtRContactnumber.Text == string.Empty && txtRPassword.Text == string.Empty)
                {
                    lblMessage.Text = "! All fields are mandatory. Enter Data to all fields";
                    return;
                }

                else if (txtRName.Text == string.Empty)
                {
                    lblMessage.Text = "! Enter User Name";
                    return;
                }

                else if (!rbtnMale.Checked && !rbtnFemale.Checked)
                {
                    lblMessage.Text = "Please choose the Gender";
                    return;
                }

                else if (txtRContactnumber.Text.Length < 10 || txtRContactnumber.Text.Length > 10)
                {
                    lblMessage.Text = "Enter correct Mobile number";
                    return;
                }
                else if (txtRUserid.Text == string.Empty && txtRUserid.TextLength<=4)
                {
                    lblMessage.Text = "! Enter Valid User ID With Minimum 5 Characters";
                    return;
                }
                
                else if (txtRPassword.Text == string.Empty && txtRPassword.TextLength <= 4)
                {
                    lblMessage.Text = "!  Enter Valid Password With Minimum 5 Characters";
                    return;
                }
              
                else if (cmbTypee.SelectedIndex == -1)
                {
                    lblMessage.Text = "Please select Type";
                    return;
                }
                else
                {

                    string genterValue;

                    if (rbtnMale.Checked == true)
                    {
                        genterValue = "Male";
                    }
                    else
                    {
                        genterValue = "Female";
                    }

                    userDTO = new UserDTO();


                    userDTO.Name = txtRName.Text;
                    userDTO.Gender = genterValue;
                    userDTO.ContactNumber = txtRContactnumber.Text;
                    userDTO.UserId = txtRUserid.Text;
                    userDTO.Password = txtRPassword.Text;
                    userDTO.Type = cmbTypee.Text;
                  
                    output = UserBL.InsertUser(userDTO);


                    if (output > 0)
                    {
                        lblMessage.Text = "Success";
                        LoadUserIDs();
                        ClearControl();
                    }
                    else
                    {
                        lblMessage.Text = "Fail";
                    }
                }

            }
            catch (Exception ef)
            {
                lblMessage.Text = ef.Message.ToString();
            }

        }
    

        private void txtRName_Validating(object sender, CancelEventArgs e)
        {

        }

        private void rbtnMale_Validating(object sender, CancelEventArgs e)
        {
          
        }

        private void txtRContactnumber_Validating(object sender, CancelEventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {
           
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            
        }



        //Deleting User--------------------------------------------

        private void btnDeleteUser_Click(object sender, EventArgs e)
        {
            int output = 0;
            try
            {
                if (MessageBox.Show("DO YOU WANT TO DELETE ? ", "S I S",
                    MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    output = UserBL.DeleteItem(cmbDeleteuser.Text);
                }
                if (output > 0)
                {
                    lblMessage.Text = " details deleted succesfully";
                    LoadUserIDs();

                }
                else
                {
                    lblMessage.Text = "try again later";
                }
            }
            catch (Exception e7)
            {
                lblMessage.Text = e7.Message.ToString();
            }
            
        }



        //Load UserIDs-------------------------------------------------------

        private void LoadUserIDs()
        {
            DataSet dsStockID = null;
            try
            {
                dsStockID = UserBL.GetUserID();
                if (dsStockID != null)
                {
                    cmbDeleteuser.DataSource = dsStockID.Tables[0];


                    cmbDeleteuser.ValueMember = "UserId";
                    cmbDeleteuser.DisplayMember = "UserId";

                }
                else
                {
                    lblMessage.Text = "No students avialbale";
                }
            }
            catch (Exception ex)
            {
                lblMessage.Text = ex.Message.ToString();

            }
        }



        private void RegistrationForm_Load(object sender, EventArgs e)
        {
            LoadUserIDs();
            ClearControl();
        }



        //Load details in form According to selection in combobox------------------------

        private void cmbDeleteuser_SelectedIndexChanged(object sender, EventArgs e)
        {
            UserDTO userDTO = null;
            try
            {
                userDTO = UserBL.GetUserIdBy(cmbDeleteuser.Text);

                if (userDTO != null)
                {
                    txtRName.Text = userDTO.Name;
                    txtRContactnumber.Text = userDTO.ContactNumber;
                    txtRUserid.Text = userDTO.UserId;
                    
                }
            }
            catch (Exception ee)
            {
                lblMessage.Text = ee.Message.ToString();
            }
        }

        private void txtRUserid_Validating(object sender, CancelEventArgs e)
        {

        }

        private void txtRPassword_Validating(object sender, CancelEventArgs e)
        {

        }

        private void cmbTypee_Validating(object sender, CancelEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            AdminForm adminForm = new AdminForm();
            adminForm.ShowDialog();
        }



        //Clear Form--------------------------------

        private void ClearControl()
        {

            txtRContactnumber.Text = "";
            txtRName.Text = "";
            txtRUserid.Text = "";
            txtRPassword.Text = "";
            cmbTypee.Text = "";
        }

    }
}
