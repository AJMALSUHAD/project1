﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ShopifyDTO.DTO;
using ShopifyBLL.ShopifyBL;
using ShopifyApp.Cashier;

namespace ShopifyApp.Purchace
{
    public partial class PurchaceBill : Form
    {
        public PurchaceBill()
        {
            InitializeComponent();
        }

        private void PurchaceBill_Load(object sender, EventArgs e)
        {
            LoadSupplierID();
            LoadSalesHistoryGrid();
        }
        

        //Load Grid Table----------------------------------------------------------

        private void LoadSalesHistoryGrid()
        {
            DataSet Sales = null;
            try
            {
                Sales = PurchaseBL.GetPurchaseReportBL(cmbSupplierId.Text, dtpPurchaseDetails.Value.ToString("dd/MM/yyyy"));
                if (Sales != null)
                {
                    dgvPurchase.DataSource = Sales.Tables[0];
                    LoadTotal();
                }
                else
                {
                    // lblMessage.Text = "no item  is available";
                }

            }
            catch (Exception ef)
            {
                lblMessage.Text = ef.Message.ToString();
            }
        }


        //Load Supplier ID-----------------------------------------------------------

        private void LoadSupplierID()
        {
            DataSet dsSupplierID = null;
            try
            {
                dsSupplierID = ShopifyItemsBLL.GetSupplierIDs();
                if (dsSupplierID != null)
                {
                    cmbSupplierId.DataSource = dsSupplierID.Tables[0];


                    cmbSupplierId.ValueMember = "SupplierID";
                    cmbSupplierId.DisplayMember = "SupplierID";

                }
                else
                {
                    lblMessage.Text = "No students avialbale";
                }
            }
            catch (Exception ex)
            {
                lblMessage.Text = ex.Message.ToString();

            }
        }



        //Find Total---------------------------------------------------------------------

        private void LoadTotal()
        {
               
            try
            {
                lblTotal.Text = Convert.ToString( PurchaseBL.GetTotalBL(cmbSupplierId.Text, dtpPurchaseDetails.Value.ToString("dd/MM/yyyy")));
          

            }
            catch (Exception ef)
            {
                lblMessage.Text = ef.Message.ToString();
            }
        }


        //Get new Purchase ID------------------------------------------------


        public static String GetNewPurchaseId()
        {
            string NewPurchaseId = null;

            try
            {
                NewPurchaseId = PurchaseBL.GetLastPurchaseId();
            }
            catch (Exception exe)
            {
                Console.Out.WriteLine("****error :GetNewPurchaseId:" + exe.Message.ToString());
            }

            return NewPurchaseId;
        }



        private void cmbSupplierId_SelectedIndexChanged(object sender, EventArgs e)
        {
            LoadSalesHistoryGrid();
        }

        private void dtpPurchaseDetails_ValueChanged(object sender, EventArgs e)
        {
            LoadSalesHistoryGrid();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {
           
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }



        //Submit Method-----------------------------------------------------

        private void txtSub_Click(object sender, EventArgs e)
        {
            PurchaseDTO purchaseDTO = null;
            int output = 0;
            try
            {
                purchaseDTO = new PurchaseDTO();
                
                purchaseDTO.TotalPrice = Convert.ToDouble(lblTotal.Text);
                purchaseDTO.Date = dtpPurchaseDetails.Value.ToString("dd/MM/yyyy");
                purchaseDTO.Supplierid = cmbSupplierId.Text;

                output = PurchaseBL.PurchaseEachInsertBL(purchaseDTO);

                if (output ==1)
                {
                    lblMessage.Text = "The bill is already paid...!";
                }
                else
                {
                    purchaseDTO.Purchaseid = GetNewPurchaseId();
                    output = PurchaseBL.PurchaseInsertBL(purchaseDTO);
                    lblMessage.Text = "Success......";
                }

            }
            catch (Exception exe)
            {
                Console.Out.WriteLine("****error : txtSub_Click" + exe.Message.ToString());
            }
        }



        private void btnBack_Click(object sender, EventArgs e)
        {
            CashierMenu objCM = new CashierMenu();
            this.Hide();
            objCM.Show();
        }
        
    }
}
