﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ShopifyApp.Cashier;
using ShopifyBLL.ShopifyBL;


namespace ShopifyApp.Purchace
{
    public partial class PurchaseReport : Form
    {
        public PurchaseReport()
        {
            InitializeComponent();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Hide();
            CashierMenu cashierMenu = new CashierMenu();
            cashierMenu.Show();
        }

        private void PurchaseReport_Load(object sender, EventArgs e)
        {
            LoadPurchaseHistoryGrid();
        }


        private void LoadPurchaseHistoryGrid()
        {
            DataSet purchase = null;
            try
            {

                purchase = PurchaseBL.GetPurchaseReportBL();

                if (purchase != null)
                {
                    dgvPurchaseReport.DataSource = purchase.Tables[0];

                }
                else
                {
                     lblMessage.Text = "No Purchase Yet";
                }

                

            }
            catch (Exception ef)
            {
                lblMessage.Text = ef.Message.ToString();
            }
        }

    }
}
