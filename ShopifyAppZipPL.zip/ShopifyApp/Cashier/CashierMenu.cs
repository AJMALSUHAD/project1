﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ShopifyApp.Purchace;
using ShopifyApp.User;

namespace ShopifyApp.Cashier
{
    public partial class CashierMenu : Form
    {
        public CashierMenu()
        {
            InitializeComponent();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            //Goto Purchase Billing

            Purchace.PurchaceBill objPB = new Purchace.PurchaceBill();
            this.Hide();
            objPB.Show();
        }

        private void btnSalesBilling_Click(object sender, EventArgs e)
        {
            //Goto Sales Billing

            SalesBilling objSB = new SalesBilling();
            this.Hide();
            objSB.Show();
        }

        private void btnSalesReport_Click(object sender, EventArgs e)
        {
            //Goto Sales Report

            SalesReport objSB = new SalesReport();
            this.Hide();
            objSB.Show();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void btnPurchaseReport_Click(object sender, EventArgs e)
        {
            //Goto Purchase Report

           PurchaseReport objSB = new PurchaseReport();
            this.Hide();
            objSB.Show();
        }

        private void lblChangePassword_Click(object sender, EventArgs e)
        {
            //Goto Change PAssword Page

            this.Hide();
            ChangePassword changePassword = new ChangePassword();
            changePassword.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //Goto Login page

            this.Hide();
            LoginForm loginForm = new LoginForm();
            loginForm.Show();
        }
    }
}
