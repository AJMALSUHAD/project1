﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ShopifyDTO.DTO;
using ShopifyBLL.ShopifyBL;

namespace ShopifyApp.Cashier
{
    public partial class SalesReport : Form
    {
        public SalesReport()
        {
            InitializeComponent();
        }

        private void LoadSalesHistoryGrid()
        {
            DataSet Sales = null;
            try
            {

                Sales = SalesBL.GetSalesReportBL();

                if (Sales != null)
                {
                    dgvSaleReport.DataSource = Sales.Tables[0];

                }
                else
                {
                   // lblMessage.Text = "no item  is available";
                }


                //DataSet contactAddress = null;
                //try
                //{

                //    contactAddress = AddressBookBl.GetAddressBL();

                //    if (contactAddress != null)
                //    {
                //        dgvAddressbook.DataSource = contactAddress.Tables[0];

                //    }
                //    else
                //    {
                //        lblMessage.Text = "no Contact is available";
                //    }

                //}
                //catch (Exception ef)
                //{
                //    lblMessage.Text = ef.Message.ToString();
                //}

            }
            catch (Exception ef)
            {
                lblMessage.Text = ef.Message.ToString();
            }
        }

        private void SalesReport_Load(object sender, EventArgs e)
        {
            LoadSalesHistoryGrid();
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Hide();
            CashierMenu cashierMenu = new CashierMenu();
            cashierMenu.Show();
        }
    }
}
