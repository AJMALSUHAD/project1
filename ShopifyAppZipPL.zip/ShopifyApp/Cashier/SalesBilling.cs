﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ShopifyDTO.DTO;
using ShopifyBLL.ShopifyBL;

namespace ShopifyApp.Cashier
{
    public partial class SalesBilling : Form
    {
        public SalesBilling()
        {
            InitializeComponent();
        }


        //back method-------------------------------------------------------

        private void btnBack_Click(object sender, EventArgs e)
        {
            CashierMenu objCM = new CashierMenu();
            this.Hide();
            objCM.Show();
        }



        //clear Form--------------------------------------------------------------

        private void ClearControl()
        {
            lblMessage.Text = "";

            cmpProductId.Text = "";
            cmpProductName.Text = "";
            txtProductQuantity.Text = "";
            txtTotal.Text = "";
            txtUnitPrice.Text = "";
        }


        //Load Products ID------------------------------------------------------

        private void LoadProductIds()
        {
            DataSet ProductIds = null;
            try
            {

                ProductIds = SalesBL.GetProductIds();

                if (ProductIds != null)
                {
                    cmpProductId.DataSource = ProductIds.Tables[0];
                    cmpProductId.ValueMember = "ProductID";
                    cmpProductId.DisplayMember = "ProductID";

                }
                else
                {
                    lblMessage.Text = "No contact Product is available";
                }
            }
            catch (Exception ef)
            {
                lblMessage.Text = ef.Message.ToString();
            }
        }


        //Load Product Names------------------------------------------------

        private void LoadProductNames()
        {
            DataSet ProductIds = null;
            try
            {

                ProductIds = SalesBL.GetProductNames();

                if (ProductIds != null)
                {
                    cmpProductName.DataSource = ProductIds.Tables[0];
                    cmpProductName.ValueMember = "ProductName";
                    cmpProductName.DisplayMember = "ProductName";

                }
                else
                {
                    lblMessage.Text = "No contact Product is available";
                }
            }
            catch (Exception ef)
            {
                lblMessage.Text = ef.Message.ToString();
            }
        }


        //Load Sales report Grid--------------------------------------------------

        private void LoadSalesHistoryGrid()
        {
            DataSet Sales = null;
            try
            {

                Sales = SalesBL.GetSalesBL(txtSalesId.Text);

                if (Sales != null)
                {
                    dgvSalesHistory.DataSource = Sales.Tables[0];

                }
                else
                {
                    lblMessage.Text = "no item  is available";
                }

            }
            catch (Exception ef)
            {
                lblMessage.Text = ef.Message.ToString();
            }
        }




        //Auto incrementation of sales ID-------------------------------------


        public static String GetNewSalesId()
        {
            string NewSalesId = null;

            try
            {
                NewSalesId = SalesBL.GetLastSalesId();
            }
            catch (Exception exe)
            {
                Console.Out.WriteLine("****error : StudentMarkBl.cs:GetNewStudentId:" + exe.Message.ToString());
            }

            return NewSalesId;
        }


        //-------------------Loadin Customer Nuumber------------------------

        private void LoadCustomerNumber()
        {
            DataSet CustomerNumber = null;
            try
            {

                CustomerNumber = CustomerBL.GetCustomerNumber();

                if (CustomerNumber != null)
                {
                    cmbLoadCustomerNumber.DataSource = CustomerNumber.Tables[0];
                    cmbLoadCustomerNumber.ValueMember = "ContactNumber";
                    cmbLoadCustomerNumber.DisplayMember = "ContactNumber";

                }
                else
                {
                    lblMessage.Text = "No contact Product is available";
                }
            }
            catch (Exception ef)
            {
                lblMessage.Text = ef.Message.ToString();
            }
        }




        //---------------Add next Item in The Cart----------------------------

        private void btnNext_Click(object sender, EventArgs e)
        {
            SalesDTO shopifyItems = null;
            int output = 0;
            try
            {
                if (txtSalesId.Text == string.Empty && cmpProductId.Text == string.Empty && cmpProductName.Text == string.Empty && txtProductQuantity.Text == string.Empty && txtUnitPrice.Text == string.Empty && txtTotal.Text == string.Empty)
                {
                    lblMessage.Text = "! All fields are mandatory. Enter Data to all fields";
                    return;
                }
                else if (txtSalesId.Text == string.Empty)
                {
                    lblMessage.Text = "! Enter Sales ID";
                    return;
                }
                else if (cmpProductId.Text == string.Empty)
                {
                    lblMessage.Text = "! Enter Product Id";
                    return;
                }
                else if (cmpProductName.Text == string.Empty)
                {
                    lblMessage.Text = "! Enter Product Name";
                    return;
                }
                else if (txtProductQuantity.Text == string.Empty)
                {
                    lblMessage.Text = "! Enter Product Quantity";
                    return;
                }
                else
                {
                    shopifyItems = new SalesDTO();


                    shopifyItems.Salesid = txtSalesId.Text;
                    shopifyItems.Productid = cmpProductId.Text;
                    shopifyItems.Productname = cmpProductName.Text;
                    shopifyItems.Quantity = Convert.ToInt64(txtProductQuantity.Text);
                    shopifyItems.Unitprice = Convert.ToInt64(txtUnitPrice.Text);
                    
                    shopifyItems.Salesdate = lblDate.Text ;
                    


                    output = SalesBL.SaleEachInsertBL(shopifyItems);


                    if (output > 0)
                    {
                        lblMessage.Text = "Success";
                        LoadSalesHistoryGrid();
                        ClearControl();
                        LoadProductIds();
                        LoadProductNames();

                        lblTotal.Text =Convert.ToString(shopifyItems.Total);
                   
                    }
                    else
                    {
                        lblMessage.Text = "Fail";
                    }
                }

            }
            catch (Exception ef)
            {
                lblMessage.Text = ef.Message.ToString();
            }
        }



        //Loading Form-------------------------------------------------

        private void SalesBilling_Load(object sender, EventArgs e)
        {
            lblDate.Text= DateTime.Now.ToString("dd/MM/yyyy");
            txtSalesId.Text=GetNewSalesId();
            LoadProductIds();
            LoadProductNames();
            LoadCustomerNumber();

        }


        //Submit method for billing---------------------------------------

        private void btnsubmit_Click(object sender, EventArgs e)
        {
            SalesDTO salesDTO = null;
            int output = 0;
            try
            {
                salesDTO = new SalesDTO();


                salesDTO.Salesid = txtSalesId.Text;
                salesDTO.Salesdate = DateTime.Now.ToString("dd/MM/yyyy");
                salesDTO.CustomerNumber = Convert.ToInt64(cmbLoadCustomerNumber.Text);


                output = SalesBL.SalesInsertBL(salesDTO);


                if (output > 0)
                {
                    lblMessage.Text = "Success";

                    if (MessageBox.Show("Success! ? ", "S I S",MessageBoxButtons.YesNo, MessageBoxIcon.Information) == DialogResult.Yes)
                    {
                        SalesBilling objSB = new SalesBilling();
                        this.Hide();
                        objSB.Show();
                    }
                   
                }
                else
                {
                    lblMessage.Text = "Fail";
                }

            }
            catch (Exception exe)
            {
                Console.Out.WriteLine("****error : btnsubmit_Click()  " + exe.Message.ToString());
            }
        }

        private void dgvSalesHistory_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }




        private void cmpProductId_SelectedIndexChanged(object sender, EventArgs e)
        {
            SalesDTO productDetails = null;
            try
            {
                productDetails = SalesBL.GetproductbyId(cmpProductId.Text);

                if (productDetails != null)
                {
                    cmpProductName.Text = productDetails.Productname;
                    txtUnitPrice.Text = productDetails.Unitprice.ToString();
                }
            }
            catch (Exception ee)
            {
                lblMessage.Text = ee.Message.ToString();
            }
        }



        private void cmpProductName_SelectedIndexChanged(object sender, EventArgs e)
        {
            SalesDTO productDetails = null;
            try
            {
                productDetails = SalesBL.GetproductbyName(cmpProductName.Text);

                if (productDetails != null)
                {
                    cmpProductId.Text = productDetails.Productid;
                    txtUnitPrice.Text = productDetails.Unitprice.ToString();
                }
            }
            catch (Exception ee)
            {
                lblMessage.Text = ee.Message.ToString();
            }
        }



        //Finding Total Method--------------------------------------

        private void txtProductQuantity_TextChanged(object sender, EventArgs e)
        {
            
            try
            {

                txtTotal.Text = SalesBL.GetTotal(txtUnitPrice.Text, txtProductQuantity.Text);

            }
            catch (Exception ef)
            {
                lblMessage.Text = ef.Message.ToString();
            }
        }

        private void txtTotal_TextChanged(object sender, EventArgs e)
        {

        }

        private void lblCustomerAdd_Click(object sender, EventArgs e)
        {
            CustomerDetails customerDetails = new CustomerDetails();
            this.Hide();
            customerDetails.Show();
        }
    }
}
