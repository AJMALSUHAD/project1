﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ShopifyDTO.DTO;
using ShopifyBLL.ShopifyBL;

namespace ShopifyApp.Cashier
{
    public partial class CustomerDetails : Form
    {
        public CustomerDetails()
        {
            InitializeComponent();
        }


        //Add customers -------------------------------------

        private void btnAddcustomer_Click(object sender, EventArgs e)
        {
            CustomerDTO customerDTO = null;
            int output = 0;
            try
            {
                if (txtCustomerID.Text == string.Empty && txtCustomerName.Text == string.Empty && txtCustomerNumber.Text == string.Empty)
                {
                    lblMessage.Text = "! All fields are mandatory. Enter Data to all fields";
                    return;
                }
                else if (txtCustomerID.Text == string.Empty)
                {
                    lblMessage.Text = "! Enter customer ID";
                    return;
                }
                else if (txtCustomerName.Text == string.Empty)
                {
                    lblMessage.Text = "! Enter Customer Name";
                    return;
                }
                else if(txtCustomerNumber.Text == string.Empty || txtCustomerNumber.TextLength!=10)
                {
                    lblMessage.Text = "! Enter Proper Mobile Number ";
                    return;
                }
                
                else
                {
                    customerDTO = new CustomerDTO();


                    customerDTO.Customerid = txtCustomerID.Text;
                    customerDTO.CustomerName= txtCustomerName.Text;
                    customerDTO.CustomerNumber= Convert.ToInt64(txtCustomerNumber.Text);
                    
                    
                    output = CustomerBL.CustomerInsertBL(customerDTO);


                    if (output > 0)
                    {
                        lblMessage.Text = "Success";

                        SalesBilling objSB = new SalesBilling();
                        this.Hide();
                        objSB.Show();
                    }
                    else
                    {
                        lblMessage.Text = "Fail";
                    }
                }

            }
            catch (Exception ef)
            {
                lblMessage.Text = ef.Message.ToString();
            }
        }



       
        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            SalesBilling salesBilling = new SalesBilling();
            salesBilling.Show();
        }
    }
}

