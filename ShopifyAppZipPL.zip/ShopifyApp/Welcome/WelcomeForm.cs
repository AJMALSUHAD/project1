﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ShopifyApp
{
    public partial class WelcomeForm : Form
    {
        public WelcomeForm()
        {
            InitializeComponent();
        }

     

        private void WelcomeForm_Shown(object sender, EventArgs e)
        {
            timer1.Interval = 3000;
            timer1.Start();
            //timer1.Tick += timer1_Tick;
            
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            timer1.Stop();           
            this.Hide();
            LoginForm loginForm = new LoginForm();
            
           loginForm.Show();
        }

        private void WelcomeForm_Load(object sender, EventArgs e)
        {

        }
    }
}
